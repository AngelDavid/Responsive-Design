require 'spec_helper'

describe Event do
  pending "add some examples to (or delete) #{__FILE__}"
end
