require 'spec_helper'

describe IdentitiesController do

end
