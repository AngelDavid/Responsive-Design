require 'spec_helper'

describe "authentication/destroy.html.erb" do
  pending "add some examples to (or delete) #{__FILE__}"
end
