# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
OmniauthApp::Application.config.secret_token = 'b3d5145e9471b0ebad483b22cbbfb4a0796a05a1df72ab779ed00ab5f4cbf60f800df7646d1fa64ee4f14b29a55c67c9e81055cd835440763e160cf1bfc78cf3'
