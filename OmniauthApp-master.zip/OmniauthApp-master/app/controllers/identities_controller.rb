class IdentitiesController < ApplicationController
end
