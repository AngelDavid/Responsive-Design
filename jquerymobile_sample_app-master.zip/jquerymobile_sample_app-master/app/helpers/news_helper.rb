module NewsHelper
end
