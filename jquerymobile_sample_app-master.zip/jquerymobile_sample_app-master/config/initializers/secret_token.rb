# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
BpApp::Application.config.secret_token = 'ca40b4ae4a6be405d9262a4c502a7d7c46ee40a5b698cc9ea86113aab626c92389e4aa529e76aeec0cbc4a74bab7a9417e52519627637ec58a6c0da43ac295d8'
