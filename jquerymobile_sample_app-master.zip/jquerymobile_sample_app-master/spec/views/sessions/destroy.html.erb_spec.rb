require 'spec_helper'

describe "sessions/destroy.html.erb" do
 
end
