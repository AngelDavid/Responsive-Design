require 'spec_helper'

describe "sessions/create.html.erb" do
 
end
