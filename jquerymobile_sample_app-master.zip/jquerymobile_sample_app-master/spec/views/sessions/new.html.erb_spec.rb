require 'spec_helper'

describe "sessions/new.html.erb" do
  
end
