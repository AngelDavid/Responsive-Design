require 'spec_helper'

describe "session/create.html.erb" do
  pending "add some examples to (or delete) #{__FILE__}"
end
