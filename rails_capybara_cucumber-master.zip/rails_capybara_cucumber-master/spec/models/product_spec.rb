require 'spec_helper'

describe Product do
  
end
