require 'spec_helper'

describe Account do
  
end
