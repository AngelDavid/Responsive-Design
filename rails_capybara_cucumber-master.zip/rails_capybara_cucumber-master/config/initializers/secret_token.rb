# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
RailsCapybaraCucumber::Application.config.secret_token = '097000d90ea6f7e70bd8dc1a020c501b5f38c6072180b74aaf5597db5c092e5e8b2d680f3f3d304fa6761666f3e5a77ff64238a1e6c3b810d1e413af7d6af318'
