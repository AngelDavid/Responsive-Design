class Account < ActiveRecord::Base
  attr_accessible :user, :acc_type, :area
 
end
