class Product < ActiveRecord::Base
  attr_accessible :title, :price, :description
 
end
